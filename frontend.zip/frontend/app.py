from flask import Flask, render_template, request, redirect, url_for, jsonify
import psycopg2
from psycopg2 import sql
from werkzeug.security import generate_password_hash

app = Flask(__name__)

# PostgreSQL database connection
def get_db_connection():
    conn = psycopg2.connect(
        host="localhost",  # Connect to localhost where the container is mapped
        database="login_database",
        user="user1",
        password="password1",
        port="5433"  # PostgreSQL's mapped port
    )
    return conn

@app.route('/')
def index():
    return render_template('login.html')  # Serve the login HTML file

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    conn = get_db_connection()
    cur = conn.cursor()

    # Store user login details in the database
    insert_query = sql.SQL("INSERT INTO users (username, password) VALUES (%s, %s)")
    cur.execute(insert_query, (username, password))
    
    conn.commit()

    cur.close()
    conn.close()

    return redirect(url_for('index'))

# Sign-up API
@app.route('/sign-up', methods=['POST'])
def sign_up():
    data = request.get_json()
    first_name = data.get('first_name')
    last_name = data.get('last_name')
    email = data.get('email')
    password = data.get('password')

    if not first_name or not last_name or not email or not password:
        return jsonify({'error': 'Please fill out all fields.'}), 400

    # Hash the password for security
    hashed_password = generate_password_hash(password, method='sha256')

    # Insert user data into the database
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            'INSERT INTO users (first_name, last_name, email, password) VALUES (%s, %s, %s, %s)',
            (first_name, last_name, email, hashed_password)
        )
        conn.commit()
        cur.close()
        conn.close()
    except psycopg2.errors.UniqueViolation:
        return jsonify({'error': 'Email already registered.'}), 409

    return jsonify({'message': 'User created successfully.'}), 201

if __name__ == '__main__':
    app.run(debug=True, port=5001)
